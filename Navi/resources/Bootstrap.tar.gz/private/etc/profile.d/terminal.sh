if [[ $TERM = network || -z $TERM ]]; then
    export TERM=linux
fi
